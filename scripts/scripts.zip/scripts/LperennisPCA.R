#'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
#'
#' L. perennis PCA
#' @date 2024-07-31
#' @author Cooper Kimball-Rhines
#' 
#'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

# Load required libraries
library(adegenet)
library(vcfR)
library(dplyr)
library(ggplot2)
library(ggpubr)

lpvcf <- read.vcfR("2.stacks/refMAF/populations.snps.vcf")

# Load in popfile from STACKS run
popList <- read.csv(file = "3.pca/noOut.csv")

# Generate a genind file for adegenet
lupine <- vcfR2genind(lpvcf, pop = popList, return.alleles = TRUE)

# Check for missing data
sum(is.na(lupine$tab))
# There are X NAs

# Replace NAs with mean allele frequency
lupine_data <- scaleGen(lupine, NA.method = "mean")
# Check it worked
dim(lupine_data)

save(lupine_data, file = "lupineDataMean.Rdata")

# Generate PCA
lupinePCA1 <- dudi.pca(lupine,
                       cent = FALSE, scale = FALSE, SCANNF = FALSE)

# Calculate Axis variance
vals <- read.delim(file = "3.pca/noOutEvals.ssv", sep = " ")
variance <- 100*vals/sum(vals)
head(variance)
# Axis1: 4.37%
# Axis2: 3.14%
# Axis3: 2.75%
# Axis4: 2.65%

# Combine the eigenvectors with population info
eigen <- read.delim(file = "3.pca/noOutEvecs.ssv", header= TRUE, sep = " ") |>
  cbind(popList) |>
  select(!X) |>
  rename(pop = V1)

#### Vizualize
# First, here are our populations grouped by state from north to south:
# CL, 92-CL
# AB, CN, HK, 92-HK
# SA, AL, MO
# C, P, M, F, PM
# ANF, BW, NK

# And here's the order they output in (alphabetical):
unique(popList$V1)

# Now here are the matching colors:

pal <- c("#DC136C","#FFD166", "#F78764", "#63A46C", "#700548",
  "#E2A3C7","#023047","#AD343E","#EC7D10","#33FFFF","#DE9E36",
  "#219ebc","#478978","#C200FB","#778da9",  "#58A4B0","#63D471")
         
# Plot, taking out that one crazy outlier point
#Everything: Super clear distinction with lat. on Axis1 and long. on Axis2
noOutAll <- ggplot(data = eigen, mapping = aes(x = Axis1, y = Axis2, color = pop)) +
  geom_point(size = 2) +
  scale_color_manual(values = pal) +
  ggtitle("L. perennis PCA by populations \nwith 1.4 million SNPs") +
  guides(size = "none") +
  theme_classic()

png(filename= "noOutAll.png", width = 900, height = 500)
noOutAll
dev.off()


# Axes 1 and 2 by population sets
#Florida
ggplot(data= eigen |> filter(V1 %in% c("AL", "NK", "BW", "ANF")), 
       mapping = aes(x= Axis1, y = Axis2, color = V1)) +
  geom_point()
  

#Old and New
ggplot(data= eigen |> filter(V1 %in% c("CL", "92-CL", "AL", "HK", "92-HK", "AB")), 
       mapping = aes(x= Axis1, y = Axis2, color = V1)) +
  geom_point()

#Midwest
ggplot(data= eigen |> filter(V1 %in% c("AL", "C", "F", "M", "P", "PM")), 
       mapping = aes(x= Axis1, y = Axis2, color = V1)) +
  geom_point()

#Northeast
palNE <- c("#63A46C", "#AD343E", "#EC7D10", "#478978", "#63D471")

ggplot(data= eigen |> filter(V1 %in% c("AL", "CL", "CN", "MO", "SA")), 
       mapping = aes(x= Axis1, y = Axis2, color = V1)) +
  geom_point() +
  geom_point(size = 2) +
  scale_color_manual(values = palNE) +
  ggtitle("L. perennis PCA by populations \nwith 1.4 million SNPs") +
  guides(size = "none")

# Axes 3 and 4 by population sets
#Everything: little pattern
ggplot(data = eigen, mapping = aes(x = Axis3, y = Axis4, color = V1)) +
  geom_point()

#Florida
ggplot(data= eigen |> filter(V1 %in% c("AL", "NK", "BW", "ANF")), 
       mapping = aes(x= Axis3, y = Axis4, color = V1)) +
  geom_point()

#Old and new
ggplot(data= eigen |> filter(V1 %in% c("CL", "92-CL", "AL", "HK", "92-HK", "AB")), 
       mapping = aes(x= Axis3, y = Axis4, color = V1)) +
  geom_point()

#Midwest
ggplot(data= eigen |> filter(V1 %in% c("AL", "C", "F", "M", "P", "PM")), 
       mapping = aes(x= Axis3, y = Axis4, color = V1)) +
  geom_point()

#Northeast (repeat CL)
ggplot(data= eigen |> filter(V1 %in% c("AL", "CN", "SA", "MO", "CL")), 
       mapping = aes(x= Axis3, y = Axis4, color = V1)) +
  geom_point()
