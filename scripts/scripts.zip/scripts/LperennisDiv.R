#'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
#'
#' L. perennis VCF Calculations
#' @date 2024-07-31
#' @author Cooper Kimball-Rhines
#' 
#'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

# Load required libraries
library(SNPfiltR)
library(vcfR)
library(dplyr)
library(ggplot2)
library(ggpubr)
library(tidyr)
library(hierfstat)
library(adegenet)
library(performance)
library(broom)

# Load in VCF
lpvcf <- read.vcfR("2.stacks/refMAF/populations.snps.vcf")

# Load in popMap
popList <- read.delim(file = "2.stacks/refMap", header = FALSE) |>
  rename(id = V1,
         pop = V2)

## Missingness Filtering
# Hard filter to a min depth of 5 and quality of 30
lpvcf <- hard_filter(vcfR=lpvcf, depth = 3, gq = 30) |>

# Remove loci with > 2 alleles
  filter_biallelic() |>

# Filter out non-heterozygous loci
 filter_allele_balance() |>

# Filter out very high coverage loci
#lpvcf <- max_depth(lpvcf) # Create histogram of depths to choose a cutoff
# I don't have a high depth problem, so I'm not filtering for this

# Set missingness cutoff
# missing_by_sample(vcfR=lpvcf, popmap = popList)
  missing_by_sample(cutoff = 0.96) |>

# Remove invariant sites
  min_mac(min.mac = 1)

# Subset popList to only contain subsetted populations
popList <- popList[popList$id %in% colnames(lpvcf@gt),]

# Set missingness cutoff by SNP
missing_by_snp(lpvcf)

lpvcf <- missing_by_snp(lpvcf, cutoff = 0.8) # There's more stats to do later to confirm this is good
# I'm setting this at 0.8 to keep 50k SNPs

# Write filtered vcf
write.vcf(lpvcf, "2.stacks/filtered.vcf")

# Write linkage filtered vcf
lpvcf.thin <- distance_thin(lpvcf, min.distance = 500)

write.vcf(lpvcf.thin, "2.stacks/linkageFiltered.vcf")


#### Calculate PCA
# Read in the VCF we just saved
lpvcf <- read.vcfR("2.stacks/filtered.vcf")

# Prepare population info
popList <- read.delim(file = "2.stacks/refMap", header = FALSE) |>
  rename(id = V1,
         pop = V2) |>
  filter(id %in% colnames(lpvcf@gt))

# Convert VCF to a genInd object and provide population assignments
lpInd <- vcfR2genind(lpvcf, pop = popList$pop)

# Mean missing data
x.lp <- tab(lpInd, freq = TRUE, NA.method = "mean")

# Calculate PCA
pca.lp <- dudi.pca(x.lp, center = TRUE, scale = FALSE, scannf = FALSE, nf = 125)

# Save eigens
eigCoords <- pca.lp$li |>
  cbind(popList) |>
  mutate(region = pop)

write.csv(eigCoords, file = "3.pca/lpEigens.csv")


#### Graph PCA

# First, here are our populations grouped by state from north to south:
# CL, 92-CL
# AB, CN, HK, 92-HK
# SA, AL, MO
# C, P, M, F, PM
# ANF, BW, NK

eigCoords <- read.csv(file = "3.pca/lpEigens.csv")

eig.perc <- 100*pca.lp$eig/sum(pca.lp$eig)

# Plot
palPop <- c("#DC136C","#FFD166", "#F78764", "#63A46C", "#700548",
         "#E2A3C7","#023047","#AD343E","#EC7D10","#33FFFF","#DE9E36",
         "#219ebc","#478978","#C200FB","#778da9",  "#58A4B0","#63D471")

lpPops <- ggplot(data = eigCoords, mapping = aes(x = Axis1, y = Axis2, color = pop)) +
  geom_point(size = 2) +
  scale_color_manual(values = palPop) +
  ggtitle("L. perennis PCA by populations \nwith 46,000 SNPs") +
  labs(title = "L. perennis PCA by population \n with 46,000 SNPs",
       x = "Principal Component 1 (40.8%)",
       y = "Principal Component 2 (2.43%)") +
  guides(size = "none") +
  theme_classic()

png(filename= "lpAllPops.png", width = 900, height = 500)
lpPops
dev.off()

# If we want to simplify and graph by our 6 regions:
eigCoords$region <- gsub("92-CL", "Vermont", x = eigCoords$region)
eigCoords$region <- gsub("CL", "Vermont", x = eigCoords$region)
eigCoords$region <- gsub("AB", "New Hampshire", x = eigCoords$region)
eigCoords$region <- gsub("CN", "New Hampshire", x = eigCoords$region)
eigCoords$region <- gsub("92-HK", "New Hampshire", x = eigCoords$region)
eigCoords$region <- gsub("HK", "New Hampshire", x = eigCoords$region)
eigCoords$region <- gsub("SA", "New York", x = eigCoords$region)
eigCoords$region <- gsub("AL", "New York", x = eigCoords$region)
eigCoords$region <- gsub("MO", "Massachusetts", x = eigCoords$region)
eigCoords$region <- gsub("ANF", "Florida", x = eigCoords$region)
eigCoords$region <- gsub("NK", "Florida", x = eigCoords$region)
eigCoords$region <- gsub("BW", "Florida", x = eigCoords$region)
eigCoords$region <- gsub("^C$", "Mid", x = eigCoords$region)
eigCoords$region <- gsub("^PM$", "Mid", x = eigCoords$region)
eigCoords$region <- gsub("^F$", "Mid", x = eigCoords$region)
eigCoords$region <- gsub("^M$", "Mid", x = eigCoords$region)
eigCoords$region <- gsub("^P$", "Mid", x = eigCoords$region)

palReg <- c("#C200FB","#E2A3C7", "#DC136C", "#778da9", "#EC7D10", "#63A46C")

lpRegs <- ggplot(data = eigCoords, mapping = aes(x = Axis1, y = Axis2, color = region)) +
  geom_point(size = 3) +
  scale_color_manual(values = palReg) +
  labs(title = "L. perennis PCA by region with 46,000 SNPs",
       x = "Principal Component 1 (40.8%)",
       y = "Principal Component 2 (2.43%)") +
  guides(size = "none") +
  theme_classic(base_size = 16) +
  stat_ellipse(type = "norm", linetype = 2)

png(filename= "lpRegions.png", width = 900, height = 600)
lpRegs
dev.off()


#### Calculate locus-level diversity 
lpHier <- genind2hierfstat(lpInd)

#lp.div <- basic.stats(data = lpHier, diploid = TRUE, digits = 4)

# Calculate mean gene diversities by population
div <- data.frame(Hs = hierfstat::Hs(lpHier),
                  Ho = hierfstat::Ho(lpHier),
                  region = c("Vermont", "New Hampshire", "New Hampshire",
                             "New York", "Florida", "Florida", "Mid", "Vermont",
                             "New Hampshire", "Mid", "New Hampshire", "Mid", 
                             "Massachusetts", "Florida", "Mid", "Mid", "New York"))

# Calculate mean observed heterozygosities by population
lpHet <- hierfstat::Ho(lpHier)

write.csv(x = div, file = "lpDiversity.csv")

div <- read.csv(file = "lpDiversity.csv") |>
  mutate(Pop = X,
         Region = c("Vermont", "New Hampshire", "New Hampshire", "New York",
                    "Florida", "Florida", "Mid", "Vermont", "New Hampshire",
                    "Mid", "New Hampshire", "Mid", "Massachusetts",
                    "Florida", "Mid", "Mid", "New York"))

palReg <- c("#C200FB","#E2A3C7", "#DC136C", "#778da9", "#EC7D10", "#63A46C")


## Model ecosystem area as predictor of diversity
hetMod <- div |>
  filter(!is.na(acres)) |>
  mutate(kacres = acres/1000) |>
  lm(formula = Ho ~ kacres)

check_posterior_predictions(hetMod)
check_normality(hetMod)
check_heteroscedasticity(hetMod)

tidy(hetMod) 
# 0.00253 increase in observed heterozysogisty per 1000 acres p = 0.357


#### Graph diversity
lpDivAll <- ggplot(data = div,
       mapping = aes(x = Hs, y = Ho, 
                     color = Region)) +
  scale_color_manual(values = palReg) +
  geom_point(size = 4) +
  labs(title = "L. perennis Regional \nHeterozygosity") +
  theme_classic(base_size = 16)+
  geom_segment(aes(x = 0.018, xend = 0.15,
                   y = 0.018, yend = 0.15),
               linewidth = 0.1, linetype = "dashed")

png(filename= "lpHetAll.png", width = 900, height = 500)
lpDivAll
dev.off()


palReg <- c("#E2A3C7", "#DC136C", "#778da9", "#EC7D10", "#63A46C")

lpDivReg <- ggplot(data = div |> filter(Hs < 0.1),
       mapping = aes(x = Hs, y = Ho, 
                     color = Region)) +
  scale_color_manual(values = palReg) +
  geom_point(size = 4) +
  labs(title = "L. perennis Population Heterozygosity") +
  theme_classic(base_size = 16)+
  geom_segment(aes(x = 0.018, xend = 0.045,
                   y = 0.018, yend = 0.045),
               linewidth = 0.1, linetype = "dashed")

png(filename= "lpDivReg.png", width = 900, height = 500)
lpDivReg
dev.off()

#### Population Differentiation
# Fst between populations
lpDist <- genet.dist(lpHier)

lpDist |>
  write.table("Fst.csv")

# IBD Analysis
library(ade4)
library(vegan)

# Load in pairwise genetic and geographic distance matrices
fstDist <- read.csv("Fst.csv") |>
  select(!X) |>
  unname()

geoDist <- read.csv("geoDist.csv") |>
  select(!X) |>
  unname()

# Perform mantel test with vegan on the two matrices
vegan::mantel(as.dist(fstDist), as.dist(geoDist), method = "pearson", na.rm = TRUE)

# r=0.75 with p = 0.001


#### Inbreeding
# Calculate population-level Fis CIs by bootstrapping
inbredHier <- boot.ppfis(lpHier, nboot = 100) |>
  cbind(inbred$fis.ci, unique(popList$pop)) |>
  rename(pop = `unique(popList$pop)`) |>
  mutate(Fis = (ll+hl)/2)

write.csv(inbredHier, "inbreeding.csv")

inbredHier <- read.csv("inbreeding.csv") |>
  mutate(Region = c("Vermont", "New Hampshire", "New Hampshire", "New York",
                    "Florida", "Florida", "Mid", "Vermont", "New Hampshire",
                    "Mid", "New Hampshire", "Mid", "Massachusetts",
                    "Florida", "Mid", "Mid", "New York"))

palReg <- c("#C200FB","#E2A3C7", "#DC136C", "#778da9", "#EC7D10", "#63A46C")

# Plot Fis with confidence intervals
FisPlot <- ggplot(data = inbredHier,
       mapping = aes(x = pop, y = Fis, color = Region)) +
  geom_point(size = 2) +
  geom_errorbar(mapping = aes(ymin = ll, ymax = hl)) +
  theme_classic(base_size = 16) +
  labs(title = "Fis confidence intervals with 1000 bootstraps",
       x = "Population")

png(filename= "FisPlot.png", width = 700, height = 500)
FisPlot
dev.off()

# Just Northeast region Fis with confidence intervals
inbredRegions <- inbredHier |>
  filter(Region %in% c("Massachusetts", "New Hampshire", "New York", "Vermont")) |>
  ggplot(mapping = aes(x = pop, y = Fis, color = Region)) +
  geom_point(size = 2) +
  geom_errorbar(mapping = aes(ymin = ll, ymax = hl)) +
  theme_classic(base_size = 16) +
  labs(title = "Fis confidence intervals with 1000 bootstraps",
       x = "Population")

png(filename= "FisRegions.png", width = 700, height = 500)
inbredRegions
dev.off()

# Model population area against Fis
fisMod <- inbredHier |>
  filter(!is.na(acres)) |>
  mutate(kacres = acres/1000) |>
  lm(formula = Fis ~ kacres)

check_posterior_predictions(fisMod)
check_normality(fisMod)
check_heteroscedasticity(fisMod)

tidy(fisMod) 
# 0.0280 increase in Fis per 1000 acres p = 0.416

#### Without Florida ####
lpvcf <- read.vcfR("2.stacks/filtered.vcf")

# Convert VCF to a genInd object and provide population assignments
lpInd <- vcfR2genind(lpvcf, pop = popList$pop)

lpInd$pop # We want to keep 1:33, 52:104, 116:136

nofl <- lpInd[c(1:33, 52:104, 116:136),]

# check it worked
nofl$pop

# Mean missing data
x.nofl <- tab(nofl, freq = TRUE, NA.method = "mean")

# Calculate PCA
pca.nofl <- dudi.pca(x.nofl, center = TRUE, scale = FALSE, scannf = FALSE, nf = 100)

eig.perc <- 100*pca.nofl$eig/sum(pca.nofl$eig)

# Save eigens
noflEigs <- data.frame(coords = pca.nofl$li,
                       pops = nofl$pop,
                       Region = nofl$pop)

# If we want to simplify and graph by our 6 regions:
noflEigs$Region <- gsub("92-CL", "Vermont", x = noflEigs$Region)
noflEigs$Region <- gsub("CL", "Vermont", x = noflEigs$Region)
noflEigs$Region <- gsub("AB", "New Hampshire", x = noflEigs$Region)
noflEigs$Region <- gsub("CN", "New Hampshire", x = noflEigs$Region)
noflEigs$Region <- gsub("92-HK", "New Hampshire", x = noflEigs$Region)
noflEigs$Region <- gsub("HK", "New Hampshire", x = noflEigs$Region)
noflEigs$Region <- gsub("SA", "New York", x = noflEigs$Region)
noflEigs$Region <- gsub("AL", "New York", x = noflEigs$Region)
noflEigs$Region <- gsub("MO", "Massachusetts", x = noflEigs$Region)
noflEigs$Region <- gsub("ANF", "Florida", x = noflEigs$Region)
noflEigs$Region <- gsub("NK", "Florida", x = noflEigs$Region)
noflEigs$Region <- gsub("BW", "Florida", x = noflEigs$Region)
noflEigs$Region <- gsub("^C$", "Mid", x = noflEigs$Region)
noflEigs$Region <- gsub("^PM$", "Mid", x = noflEigs$Region)
noflEigs$Region <- gsub("^F$", "Mid", x = noflEigs$Region)
noflEigs$Region <- gsub("^M$", "Mid", x = noflEigs$Region)
noflEigs$Region <- gsub("^P$", "Mid", x = noflEigs$Region)

palReg <- c("#E2A3C7", "#DC136C", "#778da9", "#EC7D10", "#63A46C")

# Plot PCA
noflPCA <- ggplot(data = noflEigs, mapping = aes(x = coords.Axis1, y = coords.Axis2, color = Region)) +
  geom_point(size = 3) +
  scale_color_manual(values = palReg) +
  labs(title = "L. perennis PCA by region with 46,000 SNPs",
       x = "Principal Component 1 (7.90%)",
       y = "Principal Component 2 (6.39%)") +
  guides(size = "none") +
  theme_classic(base_size = 16) +
  stat_ellipse(type = "norm", linetype = 2)

png(filename= "noflPCA.png", width = 900, height = 500)
noflPCA
dev.off()

#write.csv(noflEigs, file = "3.pca/noflEigs.csv")



